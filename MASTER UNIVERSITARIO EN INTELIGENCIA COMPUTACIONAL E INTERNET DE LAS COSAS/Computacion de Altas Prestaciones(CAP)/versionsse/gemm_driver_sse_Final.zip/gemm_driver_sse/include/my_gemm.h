#ifndef MY_GEMM_H
#define MY_GEMM_H

#include "gemm_library.h"

void my_gemm(float *A, float *B, float  *C, size_t m, size_t n, size_t k);
void saxpy_gemm(float *A, float *B, float  *C, size_t m, size_t n, size_t k);

#endif
